package com.example.ccsd_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CcsdProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
